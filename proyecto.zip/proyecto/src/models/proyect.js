const mongoose = require("mongoose");

const proyectSchema = mongoose.Schema({
  nombre:{ 
     type: String,
     required: true
  },
  autor:{
     type: String,
     required: true
  },
  anio:{
     type: Number,
     required: true
  }
});
module.exports = mongoose.model('Proyecto', proyectSchema);