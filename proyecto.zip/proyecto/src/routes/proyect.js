const express = require("express");
const router = express.Router(); 
const proyectSchema = require("../models/proyect");
//crear
router.post("/proycect", (req, res) => {
   const proyecto = proyectSchema(req.body);
   proyecto
    .save()
    .then((data) => res.json(data))
    .catch((error) => res.json({ message: error }));
});
  
//Modificar 
router.put("/proyect/:id", (req, res) => {
     const { id } = req.params;
     const { nombre, edad, tipo } = req.body;
     proyectSchema
     .updateOne({ _id: id }, {
     $set: { nombre, edad, tipo }
     })
     .then((data) => res.json(data))
     .catch((error) => res.json({ message: error }));
});  
//Eliminar
router.delete("/proyect/:id", (req, res) => {
     const { id } = req.params;
     proyectSchema
     .remove({ _id: id })
     .then((data) => res.json(data))
     .catch((error) => res.json({ message: error }));
    });    
module.exports = router;
